export type LongTermMemory = {
  thisweek_focus: string;
  discussed_topics: string;
  milestones: string;
  recurring_patterns: string;
  core_belief_evolution: string;
};


