DROP TABLE IF EXISTS "assistant_feedbacks" CASCADE;--> statement-breakpoint
DROP TABLE IF EXISTS "questions" CASCADE;