ALTER TABLE "deadline_overrides" ADD COLUMN "batch_id" text;--> statement-breakpoint
ALTER TABLE "deadline_overrides" ADD COLUMN "batch_scope" text;