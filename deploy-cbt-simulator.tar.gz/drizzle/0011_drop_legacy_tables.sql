-- Drop legacy tables no longer used
DROP TABLE IF EXISTS core_persona_versions CASCADE;
DROP TABLE IF EXISTS assistant_feedbacks CASCADE;
DROP TABLE IF EXISTS questions CASCADE;
